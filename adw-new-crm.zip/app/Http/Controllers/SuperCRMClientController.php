<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

class SuperCRMClientController extends Controller
{
    public function addClient()
    {
        return view('superadmin.client.add-client');
    }

    public function clientList()
    {
        return view('superadmin.client.client-list');
    }

}
