<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Yajra\DataTables\DataTables;
use Validator;
use App\Models\User;
use Hash;

class ClientController extends Controller
{
    public function clientView()
    {
        return view('superadmin.client.client');
    }

    public function clientList()
    {
        $clients = User::whereHas('role', function ($query) {
            $query->where('role_tag', 'client');
        })->with('role')->get();

        return DataTables::of($clients)
            ->addColumn('company_name', function ($client) {
                return $client->company_name;
            })
            ->addColumn('name', function ($client) {
                return $client->name;
            })
            ->addColumn('crm_scal', function ($client) {
                $list = '<ol>';
                $list .= '<li>' .'NA'. '</li>';
                $list .= '<li>' . 'NA'. '</li>';
                $list .= '</ol>';
                return $list;
            })
            ->addColumn('status', function ($client) {
                $statusClass = match ($client->status) {
                    'active' => 'text-success',
                    'inactive' => 'text-warning',
                    'delete' => 'text-danger'
                };
                return '<span class="' . $statusClass . '">' . ucfirst($client->status) . '</span>';
            })
            ->addColumn('action', function ($client) {
                return '<button class="btn btn-primary edit-btn" data-id="' . $client->id . '">
                            <i class="fas fa-pencil-alt"></i>
                        </button>
                        <button class="btn btn-danger delete-btn" data-id="' . $client->id . '">
                            <i class="fas fa-trash-alt"></i>
                        </button>';
                        
            })
            ->rawColumns(['status', 'crm_scal', 'action'])
            ->make(true);
    }

    public function clientStore(Request $request)
    {
        $rules = [
            'company_name' => 'required|string|max:255',
            'client_name' => 'required|string|max:255',
            'client_phone' => 'required|numeric|digits:10',
            'client_alt_phone' => 'nullable|numeric|digits:10',
            'login_id' => 'required|alpha_num|max:50|unique:users,login_id',
            'company_logo' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:8',
            'status' => 'required|in:active,inactive',
        ];
        
        $errors = [];
        foreach ($rules as $field => $rule) {
            $validator = Validator::make($request->only($field), [$field => $rule]);
            if ($validator->fails()) {
                $errors[$field] = $validator->errors()->first($field);
                break;
            }
        }
        
        if (!empty($errors)) {
            return response()->json(['errors' => $errors], 422);
        }
    
        $imageName = null;
        if ($request->hasFile('company_logo')) {
            $image = $request->file('company_logo');
            $imageName = uniqid() . '_' . $image->getClientOriginalName(); 
            $directory = \AppConfig::LOGO_UPLOAD_DIR_INTERNAL;
            if (!is_writable($directory)) {
                // Optionally log or handle this issue
                throw new \Exception("The directory {$directory} is not writable.");
            }
            $image->move($directory, $imageName);
        }
        
        $client = User::create([
            'role_id' => 2,
            'company_name' => $request->company_name,
            'name' => $request->client_name,
            'phone' => $request->client_phone,
            'alt_phone' => $request->client_alt_phone,
            'login_id' => $request->login_id,
            'company_logo' => $imageName,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'remember_password' => $request->password,
            'status' => $request->status,
        ]);

        return response()->json(['success' => true, 'message' => 'Client added successfully']);
    }

    public function userLimitEdit($id)
    {
        $UserLimit = User::findOrFail($id);

        return response()->json([
            'success' => true,
            'data' => [
                'id' => $UserLimit->id,
                'limit_number' => $UserLimit->limit_number,
                'status' => $UserLimit->status
            ]
        ]);
    }

    public function userLimitUpdate(Request $request)
    {
        $rules = [
            'userLimit_id' => 'required',
            'limit_number' => 'required',
            'status' => 'required',
        ];
        
        $errors = [];
        foreach ($rules as $field => $rule) {
            $validator = Validator::make($request->only($field), [$field => $rule]);
            if ($validator->fails()) {
                $errors[$field] = $validator->errors()->first($field);
                break;
            }
        }
        
        if (!empty($errors)) {
            return response()->json(['errors' => $errors], 422);
        }
  
        $UserLimit = User::where('id', $request->userLimit_id)->Update([
            'limit_number' => $request->limit_number,
            'status' => $request->status
        ]);

        return response()->json(['success' => true, 'message' => 'User Limit updated successfully']);
    }

    public function userLimitDelete(Request $request)
    {
        $UserLimit = User::where('id', $request->id)->Update([
            'status' => 'delete'
        ]);

        return response()->json(['success' => true, 'message' => 'User Limit delete successfully']);
    }
}
