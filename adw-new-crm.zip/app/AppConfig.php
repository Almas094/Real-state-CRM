<?php

class AppConfig
{
	const PROJECT_PUBLIC_DIR = "/var/www/crm-app/public";
    const BASE_HTTP = "https://app.abstractcrm.com";

	const LOGO_UPLOAD_DIR_INTERNAL = AppConfig::PROJECT_PUBLIC_DIR . "/attachments/logos";
	const LOGO_HTTP_PATH = AppConfig::BASE_HTTP . '/attachments/logo/';

}

?>
