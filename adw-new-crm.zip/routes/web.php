<?php
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\AuthController;

/* SuperCRM */
use App\Http\Controllers\SuperCRMDashboardController;
use App\Http\Controllers\SuperCRMClientController;
use App\Http\Controllers\SuperCRMBillingController;
use App\Http\Controllers\SuperCRMAlertController;
use App\Http\Controllers\RolesController;
use App\Http\Controllers\UserLimitController;


use App\Http\Controllers\ClientDashboardController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\MasterController;
use App\Http\Controllers\ClientMasterController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\ClientLeadsController;




Route::get('/', function () {
    return Auth::check() ? redirect()->route('dashboard') : redirect()->route('login');
})->name('home');

Route::middleware(['guest'])->group(function () {
    Route::get('/login', function () {
        if (Auth::check()) {
            return redirect()->route('dashboard');
        }
        return view('auth.login');
    })->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/forgot-password', [AuthController::class, 'showLinkRequestForm'])->name('password.request');
    Route::post('/forgot-password', [AuthController::class, 'sendResetLink'])->name('password.email');
    Route::get('/reset-password/{token}', [AuthController::class, 'showResetForm'])->name('password.reset');
    Route::post('/reset-password', [AuthController::class, 'reset'])->name('password.update');
});

Route::middleware(['auth'])->group(function () {
    Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::prefix('admin')->group(function () {     
        Route::get('/dashboard', [SuperCRMDashboardController::class, 'index'])->name('dashboard');
        
        Route::prefix('client')->group(function () {
            Route::get('/add-client', [SuperCRMClientController::class, 'addClient'])->name('add.client');
            Route::get('/client-list', [SuperCRMClientController::class, 'clientList'])->name('client.list');
        });
        
        Route::prefix('billing')->group(function () {
            Route::get('/invoices', [SuperCRMBillingController::class, 'invoices'])->name('invoices');
        });

        Route::prefix('alert')->group(function () {
            Route::get('/templates', [SuperCRMAlertController::class, 'alertTemplates'])->name('alert.templates');
            Route::get('/send-notification', [SuperCRMAlertController::class, 'sendNotification'])->name('send.notification');
        });
        
        
        
         Route::prefix('master')->group(function () {

            Route::prefix('roles')->group(function () {
                Route::get('', [RolesController::class, 'index'])->name('master.roles.index');
                Route::get('/list', [RolesController::class, 'list'])->name('master.roles.list');
                Route::post('/store', [RolesController::class, 'store'])->name('master.roles.store');
                Route::get('/edit/{id}', [RolesController::class, 'edit'])->name('master.roles.edit');
                Route::put('/update/{id}', [RolesController::class, 'update'])->name('master.roles.update');
                Route::delete('/delete/{id}', [RolesController::class, 'delete'])->name('master.roles.delete');
                Route::post('/update-status', [RolesController::class, 'updateStatus'])->name('master.roles.updateStatus');
            });
            
            Route::prefix('user-limit')->group(function () {
                Route::get('', [UserLimitController::class, 'index'])->name('master.user.limit.index');
                Route::get('/list', [UserLimitController::class, 'list'])->name('master.user.limit.list');
                Route::post('/store', [UserLimitController::class, 'store'])->name('master.user.limit.store');
                Route::get('/edit/{id}', [UserLimitController::class, 'edit'])->name('master.user.limit.edit');
                Route::put('/update/{id}', [UserLimitController::class, 'update'])->name('master.user.limit.update');
                Route::delete('/delete/{id}', [UserLimitController::class, 'delete'])->name('master.user.limit.delete');
                Route::post('/update-status', [UserLimitController::class, 'updateStatus'])->name('master.user.limit.update.status');
            });

            Route::get('/subscription', [MasterController::class, 'subscriptionView'])->name('master.subscription');
            Route::post('/subscription-list', [MasterController::class, 'subscriptionList'])->name('master.subscription.list');
            Route::post('/subscription-store', [MasterController::class, 'subscriptionStore'])->name('master.subscription.store');
            Route::get('/subscription-edit/{id}', [MasterController::class, 'subscriptionEdit'])->name('master.subscription.edit');
            Route::post('/subscription-update', [MasterController::class, 'subscriptiontUpdate'])->name('master.subscription.update');
        });

        Route::prefix('permission')->group(function () {
            Route::get('/menu', [PermissionController::class, 'menuView'])->name('permission.menu');
            Route::post('/menu-list', [PermissionController::class, 'menuList'])->name('permission.menu.list');
            Route::post('/menu-store', [PermissionController::class, 'menuStore'])->name('permission.menu.store');
            Route::get('/menu-edit/{id}', [PermissionController::class, 'menuEdit'])->name('permission.menu.edit');
            Route::post('/menu-update', [PermissionController::class, 'menuUpdate'])->name('permission.menu.update');
            Route::post('/submenu-delete', [PermissionController::class, 'submenuDelete'])->name('permission.submenu.delete');
        });
        Route::prefix('client')->group(function () {
            Route::get('/client', [ClientController::class, 'clientView'])->name('client');
            Route::post('/client-list', [ClientController::class, 'clientList'])->name('client.list');
            Route::post('/client-store', [ClientController::class, 'clientStore'])->name('client.store');
            Route::get('/client-edit/{id}', [ClientController::class, 'userLimitEdit'])->name('client.edit');
            Route::post('/client-update', [ClientController::class, 'userLimitUpdate'])->name('client.update');
            Route::post('/client-delete', [ClientController::class, 'userLimitDelete'])->name('client.delete');
        }); 
    });


    /* Route::prefix('client')->group(function () {     

        Route::get('/dashboard', [ClientDashboardController::class, 'index'])->name('dashboard');

        Route::prefix('master')->group(function () {

            Route::get('/configuration-list', [ClientMasterController::class, 'configurationList'])->name('master.configuration.list');
            Route::get('/location-list', [ClientMasterController::class, 'locationList'])->name('master.location.list');
            Route::get('/source-list', [ClientMasterController::class, 'sourceList'])->name('master.source.list');
            Route::get('/disposition-list', [ClientMasterController::class, 'dispositionList'])->name('master.disposition.list');
            Route::get('/subdisposition-list', [ClientMasterController::class, 'subdispositionList'])->name('master.subdisposition.list');
            
        });

        Route::prefix('leads')->group(function () {

            Route::get('/add-leads', [ClientLeadsController::class, 'addLeads'])->name('master.add.leads');
            Route::get('/all-leads', [ClientLeadsController::class, 'allLeads'])->name('master.all.leads');

            
        });

    }); */

    

});






