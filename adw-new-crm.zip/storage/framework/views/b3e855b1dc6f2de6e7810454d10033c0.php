

<?php $__env->startSection('title', 'Abstract CRM'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/dataTables.bootstrap5.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/responsive.bootstrap5.min.css')); ?>">
<?php $__env->startSection('content'); ?>
<section class="pc-container">
  <div class="pc-content">

    <div class="page-header" style="padding-top:0px; margin-top:-5px;">
      <div class="page-block">
        <div class="row align-items-center">
          <div class="col-md-12">
            <div class="page-header-title">
              <h2 class="mb-2">User Limit</h2>
            </div>
          </div>
          <div class="col-md-12">
            <ul class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item"><a>Master</a></li>
              <li class="breadcrumb-item" aria-current="page">User Limit</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5>User Limit</h5>
                <button class="btn btn-primary" id="addUserLimitButton" data-bs-toggle="modal" data-bs-target="#addUserLimitModal">
                    <i class="fas fa-plus"></i> Add User Limit
                </button>
            </div>
          <div class="card-body">
            <table id="userLimit" class="display table table-striped table-hover dt-responsive nowrap" style="width: 100%">
              <thead>
                <tr>
                  <th>Sr.No</th>
                  <th>Limit</th>
                  <th>Status</th>
                  <th>Created At</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody></tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- Add Limit Modal -->
    <?php echo $__env->make('superadmin.master.add-user-limit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Add Limit Modal -->

    <!-- Edit Limit Modal -->
    <?php echo $__env->make('superadmin.master.edit-user-limit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Edit Limit Modal -->

    <?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/plugins/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/responsive.bootstrap5.min.js')); ?>"></script>
    <script>
    $(document).ready(function() {

        $('#userLimit').DataTable({
            responsive: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "<?php echo e(route('master.user.limit.list')); ?>",
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }
            },
            columns: [
                { 
                    data: null, 
                    name: 'sr', 
                    orderable: true, 
                    searchable: true,
                    render: function (data, type, row, meta) {
                        return meta.row + 1;
                    }
                },
                { data: 'limit_number', name: 'limit_number', orderable: true  },
                { data: 'status', name: 'status', orderable: true },
                { data: 'created_at', name: 'created_at', orderable: true  },
                { data: 'action', name: 'action', orderable: false, searchable: false }
            ]
        });

        $('#show-hide-res').DataTable({
            responsive: {
                details: {
                    display: $.fn.dataTable.Responsive.display.childRowImmediate,
                    type: ''
                }
            }
        });

        //store
        $('#addUserLimitForm').on('submit', function(e) {
            e.preventDefault();

            $.ajax({
                url: "<?php echo e(route('master.user.limit.store')); ?>",
                type: 'POST',
                data: $(this).serialize(),
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    $('#addUserLimitForm')[0].reset();
                    if (response.success) {
                        $('#addUserLimitModal').modal('hide');
                        Swal.fire({
                            title: 'Success',
                            text: response.message,
                            icon: 'success',
                            confirmButtonText: 'OK'
                        });
                        $('#userLimit').DataTable().ajax.reload();
                    }
                },
                error: function(xhr) {
                    if (xhr.status === 422) {
                        let errors = xhr.responseJSON.errors;
                        let errorMessages = '';
                        $.each(errors, function(key, value) {
                            errorMessages += value + '<br>';
                        });

                        Swal.fire({
                            title: 'Validation Error',
                            html: errorMessages, 
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });

                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: 'There was an error saving the user limit.',
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                }

            });
        });

        //edit
        $(document).on('click', '.edit-btn', function () {
            var menuId = $(this).data('id');

            $.ajax({
                url: "<?php echo e(route('master.user.limit.edit', ':id')); ?>".replace(':id', menuId),
                type: 'GET',
                success: function (response) {
                    if (response.success) {
                        $('#userLimitId').val(response.data.id);
                        $('#editlimitNumber').val(response.data.limit_number);
                        $('#editstatus').val(response.data.status);
                        $('#editUserLimitModal').modal('show');
                    }
                },
                error: function () {
                    Swal.fire('Error', 'Unable to fetch details.', 'error');
                }
              });
            });

            //update
            $('#editUserLimitForm').on('submit', function(e) {
            e.preventDefault();

            $.ajax({
                url: "<?php echo e(route('master.user.limit.update')); ?>",
                type: 'POST',
                data: $(this).serialize(),
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    $('#editUserLimitForm')[0].reset();
                    if (response.success) {
                        $('#editUserLimitModal').modal('hide');
                        Swal.fire({
                            title: 'Success',
                            text: response.message,
                            icon: 'success',
                            confirmButtonText: 'OK'
                        });
                        $('#userLimit').DataTable().ajax.reload();
                    }
                },
                error: function(xhr) {
                    if (xhr.status === 422) {
                        let errors = xhr.responseJSON.errors;
                        let errorMessages = '';
                        $.each(errors, function(key, value) {
                            errorMessages += value + '<br>';
                        });

                        Swal.fire({
                            title: 'Validation Error',
                            html: errorMessages, 
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });

                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: 'There was an error update the user limit.',
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                }

            });
        });

        $(document).on('click', '.delete-btn', function () {
            var UserLimitId = $(this).data('id');

            Swal.fire({
                title: 'Are you sure?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: 'POST',
                        url: '<?php echo e(route("master.user.limit.delete")); ?>',
                        data : {id : UserLimitId},
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        success: function (response) {
                            if (response.success) {
                                Swal.fire({
                                    title: 'Deleted!',
                                    text: response.message,
                                    icon: 'success',
                                    confirmButtonText: 'OK'
                                });
                                // Reload DataTable
                                $('#userLimit').DataTable().ajax.reload();
                            }
                        },
                        error: function () {
                            Swal.fire({
                                title: 'Error!',
                                text: 'An error occurred while deleting the menu.',
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    });
                }
            });
        });


    });
 </script>
 <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/crm-app/resources/views/superadmin/master/user-limit.blade.php ENDPATH**/ ?>