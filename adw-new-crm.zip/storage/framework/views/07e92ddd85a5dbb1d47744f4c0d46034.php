

<?php $__env->startSection('title', 'Abstract CRM'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/dataTables.bootstrap5.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/responsive.bootstrap5.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/animate.min.css')); ?>" type="text/css">

<?php $__env->startSection('content'); ?>
<section class="pc-container">
  <div class="pc-content">

    <!-- Section Header -->
    <div class="page-header" style="padding-top:0px;">
      <div class="page-block">
        <div class="row align-items-center">
          <div class="col-md-12">
            <div class="page-header-title">
              <h4 class="mb-2">Invoices</h4>
            </div>
          </div>
          <div class="col-md-12">
            <ul class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">SuperCRM</a></li>
              <li class="breadcrumb-item"><a>Billing</a></li>
              <li class="breadcrumb-item" aria-current="page">Invoices</li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <div class="row card-row-1">
      <div class="col-sm-12">
        <div class="card">
          <div class="card-header table-header">
            <div class="row">
                <div class="col-12">
                  <ul class="nav nav-pills" id="pills-tab" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" href="#pills-all" role="tab"
                        aria-controls="pills-home" aria-selected="true">All</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" href="#pills-paid" role="tab"
                        aria-controls="pills-profile" aria-selected="false">Paid</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" href="#pills-unpaid" role="tab"
                        aria-controls="pills-contact" aria-selected="false">Unpaid</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" href="#pills-cancelled" role="tab"
                        aria-controls="pills-contact" aria-selected="false">Cancelled</a>
                    </li>
                  </ul>
                </div>
            </div>
          </div>
          <div class="card-body pc-component billing-cardbody">
            <div class="tab-content " id="pills-tabContent">
              <div class="tab-pane fade show active table-responsive" id="pills-all" role="tabpanel" aria-labelledby="pills-home-tab">
                <table class="table table-hover client-table" id="InvoiceAll">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Client Details</th>
                      <th>Subscription</th>
                      <th>Duration</th>
                      <th class="text-center">Payable Amount</th>
                      <th class="text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody class="cmb-5">
                    <tr>
                      <td>
                        <h6 class="mb-2">ADW0006</h6>
                        <p class="f-14 mb-0">01</p>
                      </td>
                      <td>
                          <h6 class="mb-2">Myspace Developers</h6>
                          <p class="f-14 mb-0">POC: Akanksha Loke</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">Users: 3</p>
                        <p class="f-14 mb-0">Validity: 6 months</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">From: 01-01-2025</p>
                        <p class="f-14 mb-0">To: 30-06-2025</p>
                      </td>
                      <td class="text-center">
                        <p class="f-14 mb-2">₹ 8999</p>
                        <span class="badge bg-light-success">Paid</span>                          
                      </td>
                      <td class="text-center">
                        <div class="btn-group mr-2 mb-2">
                          <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                          <ul class="dropdown-menu dropdown-action-1">
                            <li><a class="dropdown-item f-13" href="#" onclick="openInvoiceStatusBar()" ><i class="ti ti-edit"></i>Change Status </a></li>
                            <li><a class="dropdown-item f-13" href="#" onclick="openDownloadInvoiceBar()" ><i class="ti ti-download"></i>Download Invoice</a></li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <h6 class="mb-2">ADW0005</h6>
                        <p class="f-14 mb-0">02</p>
                      </td>
                      <td>
                          <h6 class="mb-2">Myspace Developers</h6>
                          <p class="f-14 mb-0">POC: Akanksha Loke</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">Users: 3</p>
                        <p class="f-14 mb-0">Validity: 3 months</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">From: 01-01-2025</p>
                        <p class="f-14 mb-0">To: 31-03-2025</p>
                      </td>
                      <td class="text-center">
                        <p class="f-14 mb-2">₹ 4999</p>
                        <span class="badge bg-light-danger">Unpaid</span>                          
                      </td>
                      <td class="text-center">
                        <div class="btn-group mr-2 mb-2">
                          <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                          <ul class="dropdown-menu dropdown-action-1">
                            <li><a class="dropdown-item f-13" href="#"onclick="openInvoiceStatusBar()" ><i class="ti ti-edit"></i>Change Status </a></li>
                            <li><a class="dropdown-item f-13" href="#" onclick="openDownloadInvoiceBar()" ><i class="ti ti-download"></i>Download Invoice</a></li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <h6 class="mb-2">ADW0004</h6>
                        <p class="f-14 mb-0">03</p>
                      </td>
                      <td>
                          <h6 class="mb-2">Myspace Developers</h6>
                          <p class="f-14 mb-0">POC: Akanksha Loke</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">Users: 5</p>
                        <p class="f-14 mb-0">Validity: 12 months</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">From: 01-01-2025</p>
                        <p class="f-14 mb-0">To: 07-01-2025</p>
                      </td>
                      <td class="text-center">
                        <p class="f-14 mb-2">₹ 14999</p>
                        <span class="badge bg-light-success">Paid</span>                          
                      </td>
                      <td class="text-center">
                        <div class="btn-group mr-2 mb-2">
                          <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                          <ul class="dropdown-menu dropdown-action-1">
                            <li><a class="dropdown-item f-13" href="#"onclick="openInvoiceStatusBar()" ><i class="ti ti-edit"></i>Change Status </a></li>
                            <li><a class="dropdown-item f-13" href="#" onclick="openDownloadInvoiceBar()" ><i class="ti ti-download"></i>Download Invoice</a></li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <h6 class="mb-2">ADW0003</h6>
                        <p class="f-14 mb-0">04</p>
                      </td>
                      <td>
                          <h6 class="mb-2">Myspace Developers</h6>
                          <p class="f-14 mb-0">POC: Akanksha Loke</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">Users: 6</p>
                        <p class="f-14 mb-0">Validity: 6 months</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">From: 01-01-2025</p>
                        <p class="f-14 mb-0">To: 07-01-2025</p>
                      </td>
                      <td class="text-center">
                        <p class="f-14 mb-2">₹ 12499</p>
                        <span class="badge bg-light-danger">Cancelled</span>                          
                      </td>
                      <td class="text-center">
                        <div class="btn-group mr-2 mb-2">
                          <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                          <ul class="dropdown-menu dropdown-action-1">
                            <li><a class="dropdown-item f-13" href="#"onclick="openInvoiceStatusBar()" ><i class="ti ti-edit"></i>Change Status </a></li>
                            <li><a class="dropdown-item f-13" href="#" onclick="openDownloadInvoiceBar()" ><i class="ti ti-download"></i>Download Invoice</a></li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <h6 class="mb-2">ADW0002</h6>
                        <p class="f-14 mb-0">05</p>
                      </td>
                      <td>
                          <h6 class="mb-2">Myspace Developers</h6>
                          <p class="f-14 mb-0">POC: Akanksha Loke</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">Users: 1</p>
                        <p class="f-14 mb-0">Validity: 7 days</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">From: 01-01-2025</p>
                        <p class="f-14 mb-0">To: 07-01-2025</p>
                      </td>
                      <td class="text-center">
                        <p class="f-14 mb-2">₹ 14999</p>
                        <span class="badge bg-light-success">Paid</span>                          
                      </td>
                      <td class="text-center">
                        <div class="btn-group mr-2 mb-2">
                          <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                          <ul class="dropdown-menu dropdown-action-1">
                            <li><a class="dropdown-item f-13" href="#"onclick="openInvoiceStatusBar()" ><i class="ti ti-edit"></i>Change Status </a></li>
                            <li><a class="dropdown-item f-13" href="#" onclick="openDownloadInvoiceBar()" ><i class="ti ti-download"></i>Download Invoice</a></li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <h6 class="mb-2">ADW0001</h6>
                        <p class="f-14 mb-0">06</p>
                      </td>
                      <td>
                          <h6 class="mb-2">Myspace Developers</h6>
                          <p class="f-14 mb-0">POC: Akanksha Loke</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">Users: 1</p>
                        <p class="f-14 mb-0">Validity: 7 days</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">From: 01-01-2025</p>
                        <p class="f-14 mb-0">To: 07-01-2025</p>
                      </td>
                      <td class="text-center">
                        <p class="f-14 mb-2">₹ 14999</p>
                        <span class="badge bg-light-danger">cancelled</span>                          
                      </td>
                      <td class="text-center">
                        <div class="btn-group mr-2 mb-2">
                          <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                          <ul class="dropdown-menu dropdown-action-1">
                            <li><a class="dropdown-item f-13" href="#"onclick="openInvoiceStatusBar()" ><i class="ti ti-edit"></i>Change Status </a></li>
                            <li><a class="dropdown-item f-13" href="#" onclick="openDownloadInvoiceBar()" ><i class="ti ti-download"></i>Download Invoice</a></li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="tab-pane fade table-responsive" id="pills-paid" role="tabpanel" aria-labelledby="pills-profile-tab">
                <table class="table table-hover client-table" id="InvoicePaid">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Client Details</th>
                      <th>Subscription</th>
                      <th>Duration</th>
                      <th class="text-center">Payable Amount</th>
                      <th class="text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody class="cmb-5">
                    <tr>
                      <td>
                        <h6 class="mb-2">ADW0006</h6>
                        <p class="f-14 mb-0">01</p>
                      </td>
                      <td>
                          <h6 class="mb-2">Myspace Developers</h6>
                          <p class="f-14 mb-0">POC: Akanksha Loke</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">Users: 3</p>
                        <p class="f-14 mb-0">Validity: 6 months</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">From: 01-01-2025</p>
                        <p class="f-14 mb-0">To: 30-06-2025</p>
                      </td>
                      <td class="text-center">
                        <p class="f-14 mb-2">₹ 8999</p>
                        <span class="badge bg-light-success">Paid</span>                          
                      </td>
                      <td class="text-center">
                        <div class="btn-group mr-2 mb-2">
                          <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                          <ul class="dropdown-menu dropdown-action-1">
                            <li><a class="dropdown-item f-13" href="#"onclick="openInvoiceStatusBar()" ><i class="ti ti-edit"></i>Change Status </a></li>
                            <li><a class="dropdown-item f-13" href="#" onclick="openDownloadInvoiceBar()" ><i class="ti ti-download"></i>Download Invoice</a></li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <h6 class="mb-2">ADW0004</h6>
                        <p class="f-14 mb-0">02</p>
                      </td>
                      <td>
                          <h6 class="mb-2">Myspace Developers</h6>
                          <p class="f-14 mb-0">POC: Akanksha Loke</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">Users: 5</p>
                        <p class="f-14 mb-0">Validity: 12 months</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">From: 01-01-2025</p>
                        <p class="f-14 mb-0">To: 07-01-2025</p>
                      </td>
                      <td class="text-center">
                        <p class="f-14 mb-2">₹ 14999</p>
                        <span class="badge bg-light-success">Paid</span>                          
                      </td>
                      <td class="text-center">
                        <div class="btn-group mr-2 mb-2">
                          <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                          <ul class="dropdown-menu dropdown-action-1">
                            <li><a class="dropdown-item f-13" href="#"onclick="openInvoiceStatusBar()" ><i class="ti ti-edit"></i>Change Status </a></li>
                            <li><a class="dropdown-item f-13" href="#" onclick="openDownloadInvoiceBar()" ><i class="ti ti-download"></i>Download Invoice</a></li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <h6 class="mb-2">ADW0002</h6>
                        <p class="f-14 mb-0">03</p>
                      </td>
                      <td>
                          <h6 class="mb-2">Myspace Developers</h6>
                          <p class="f-14 mb-0">POC: Akanksha Loke</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">Users: 1</p>
                        <p class="f-14 mb-0">Validity: 7 days</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">From: 01-01-2025</p>
                        <p class="f-14 mb-0">To: 07-01-2025</p>
                      </td>
                      <td class="text-center">
                        <p class="f-14 mb-2">₹ 14999</p>
                        <span class="badge bg-light-success">Paid</span>                          
                      </td>
                      <td class="text-center">
                        <div class="btn-group mr-2 mb-2">
                          <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                          <ul class="dropdown-menu dropdown-action-1">
                            <li><a class="dropdown-item f-13" href="#"onclick="openInvoiceStatusBar()" ><i class="ti ti-edit"></i>Change Status </a></li>
                            <li><a class="dropdown-item f-13" href="#" onclick="openDownloadInvoiceBar()" ><i class="ti ti-download"></i>Download Invoice</a></li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="tab-pane fade table-responsive" id="pills-unpaid" role="tabpanel" aria-labelledby="pills-contact-tab">
                <table class="table table-hover client-table" id="InvoiceUnpaid">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Client Details</th>
                      <th>Subscription</th>
                      <th>Duration</th>
                      <th class="text-center">Payable Amount</th>
                      <th class="text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody class="cmb-5">
                    <tr>
                      <td>
                        <h6 class="mb-2">ADW0005</h6>
                        <p class="f-14 mb-0">01</p>
                      </td>
                      <td>
                          <h6 class="mb-2">Myspace Developers</h6>
                          <p class="f-14 mb-0">POC: Akanksha Loke</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">Users: 3</p>
                        <p class="f-14 mb-0">Validity: 3 months</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">From: 01-01-2025</p>
                        <p class="f-14 mb-0">To: 31-03-2025</p>
                      </td>
                      <td class="text-center">
                        <p class="f-14 mb-2">₹ 4999</p>
                        <span class="badge bg-light-danger">Unpaid</span>                          
                      </td>
                      <td class="text-center">
                        <div class="btn-group mr-2 mb-2">
                          <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                          <ul class="dropdown-menu dropdown-action-1">
                            <li><a class="dropdown-item f-13" href="#"onclick="openInvoiceStatusBar()" ><i class="ti ti-edit"></i>Change Status </a></li>
                            <li><a class="dropdown-item f-13" href="#" onclick="openDownloadInvoiceBar()" ><i class="ti ti-download"></i>Download Invoice</a></li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="tab-pane fade table-responsive" id="pills-cancelled" role="tabpanel" aria-labelledby="pills-contact-tab">
                <table class="table table-hover client-table" id="InvoiceCancelled">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Client Details</th>
                      <th>Subscription</th>
                      <th>Duration</th>
                      <th class="text-center">Payable Amount</th>
                      <th class="text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody class="cmb-5">
                    <tr>
                      <td>
                        <h6 class="mb-2">ADW0003</h6>
                        <p class="f-14 mb-0">01</p>
                      </td>
                      <td>
                          <h6 class="mb-2">Myspace Developers</h6>
                          <p class="f-14 mb-0">POC: Akanksha Loke</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">Users: 6</p>
                        <p class="f-14 mb-0">Validity: 6 months</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">From: 01-01-2025</p>
                        <p class="f-14 mb-0">To: 07-01-2025</p>
                      </td>
                      <td class="text-center">
                        <p class="f-14 mb-2">₹ 12499</p>
                        <span class="badge bg-light-danger">Cancelled</span>                          
                      </td>
                      <td class="text-center">
                        <div class="btn-group mr-2 mb-2">
                          <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                          <ul class="dropdown-menu dropdown-action-1">
                            <li><a class="dropdown-item f-13" href="#"onclick="openInvoiceStatusBar()" ><i class="ti ti-edit"></i>Change Status </a></li>
                            <li><a class="dropdown-item f-13" href="#" onclick="openDownloadInvoiceBar()" ><i class="ti ti-download"></i>Download Invoice</a></li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <h6 class="mb-2">ADW0001</h6>
                        <p class="f-14 mb-0">02</p>
                      </td>
                      <td>
                          <h6 class="mb-2">Myspace Developers</h6>
                          <p class="f-14 mb-0">POC: Akanksha Loke</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">Users: 1</p>
                        <p class="f-14 mb-0">Validity: 7 days</p>
                      </td>
                      <td>
                        <p class="f-14 mb-2">From: 01-01-2025</p>
                        <p class="f-14 mb-0">To: 07-01-2025</p>
                      </td>
                      <td class="text-center">
                        <p class="f-14 mb-2">₹ 14999</p>
                        <span class="badge bg-light-danger">cancelled</span>                          
                      </td>
                      <td class="text-center">
                        <div class="btn-group mr-2 mb-2">
                          <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                          <ul class="dropdown-menu dropdown-action-1">
                            <li><a class="dropdown-item f-13" href="#"onclick="openInvoiceStatusBar()" ><i class="ti ti-edit"></i>Change Status </a></li>
                            <li><a class="dropdown-item f-13" href="#" onclick="openDownloadInvoiceBar()" ><i class="ti ti-download"></i>Download Invoice</a></li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- FilterBar -->
    <?php echo $__env->make('superadmin.billing.invoice-status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- DownloadInvoiceBar -->
    <?php echo $__env->make('superadmin.billing.download-invoice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="sdbr-overlay" class="sdbr-overlay" onclick="closeAllSidebars()"></div>

  <?php $__env->startPush('scripts'); ?>


<!-- [Page Specific JS] start -->
<script src="<?php echo e(asset('assets/js/plugins/simple-datatables.js')); ?>"></script>
<script>
  const invoiceAllTable = new simpleDatatables.DataTable('#InvoiceAll', {
    sortable: false,
    perPage: 5
  });

  const invoicePaidTable = new simpleDatatables.DataTable('#InvoicePaid', {
    sortable: false,
    perPage: 5
  });

  const invoiceUnpaidTable = new simpleDatatables.DataTable('#InvoiceUnpaid', {
    sortable: false,
    perPage: 5
  });

  const invoiceCancelledTable = new simpleDatatables.DataTable('#InvoiceCancelled', {
    sortable: false,
    perPage: 5
  });
</script>


<!-- Sidebars -->
<script>

  const overlay = document.getElementById('sdbr-overlay');

  function openInvoiceStatusBar() {
    const sidebar = document.getElementById('InvoiceStatusBar');
    sidebar.classList.add('open');
    overlay.classList.add('show');
  }

  function closeInvoiceStatusBar() {
    const sidebar = document.getElementById('InvoiceStatusBar');
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
  }

  function openDownloadInvoiceBar() {
    const sidebar = document.getElementById('DownloadInvoice');
    sidebar.classList.add('open');
    overlay.classList.add('show');
  }

  function closeDownloadInvoiceBar() {
    const sidebar = document.getElementById('DownloadInvoice');
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
  }

  function closeAllSidebars() {
    closeInvoiceStatusBar();
    closeDownloadInvoiceBar();
  }

</script>




 <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.supercrm-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/crm-app/resources/views/superadmin/billing/invoice-list.blade.php ENDPATH**/ ?>