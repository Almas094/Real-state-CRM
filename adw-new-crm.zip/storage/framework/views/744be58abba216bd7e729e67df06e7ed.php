<nav class="pc-sidebar">
  <div class="navbar-wrapper">
    <div class="m-header">
      <a href="#" class="b-brand text-primary">
        <img src="<?php echo e(asset('assets/images/adwcrm.svg')); ?>" alt="img" width="150px" />
        <span class="badge bg-light-success rounded-pill ms-2">v0.1</span>
      </a>
    </div>
    <div class="navbar-content">
      <div class="card pc-user-card">
        <div class="card-body">
          <div class="d-flex align-items-center">
            <div class="flex-shrink-0">
              <img src="<?php echo e(asset('assets/images/user/adw001.jpg')); ?>" alt="user-image" class="user-avtar wid-45 rounded-circle" />
            </div>
            <div class="flex-grow-1 ms-3 me-2">
              <h6 class="mb-0">Raj Makhija</h6>
              <small>Administrator</small>
            </div>
            <a class="btn btn-icon btn-link-secondary avtar-s" data-bs-toggle="collapse" href="#pc_sidebar_userlink">
              <svg class="pc-icon">
                <use xlink:href="#custom-sort-outline"></use>
              </svg>
            </a>
          </div>
          <div class="collapse pc-user-links" id="pc_sidebar_userlink">
            <div class="pt-3">
              <a href="#!">
                <i class="ti ti-user"></i>
                <span>My Profile</span>
              </a>
              <a href="#!">
                <i class="ti ti-bell-ringing"></i>
                <span>Notification</span>
              </a>
              <a href="#!">
                <i class="ti ti-power"></i>
                <span>Logout</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      <ul class="pc-navbar">
       <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidebar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($sidebar->have_submenu === 'No'): ?>
        <li class="pc-item">
          <a href="<?php echo e(route($sidebar->route_name)); ?>" class="pc-link">
            <span class="pc-micon">
              <svg class="pc-icon">
                <use xlink:href="<?php echo e($sidebar->icon_class_name); ?>"></use>
              </svg>
            </span>
            <span class="pc-mtext"><?php echo e($sidebar->name); ?></span>
          </a>
        </li>
        <?php else: ?>
        <li class="pc-item pc-hasmenu">
          <a href="#" class="pc-link">
            <span class="pc-micon">
              <svg class="pc-icon">
                <use xlink:href="<?php echo e($sidebar->icon_class_name); ?>"></use>
              </svg>
            </span>
            <span class="pc-mtext"><?php echo e($sidebar->name); ?></span>
            <span class="pc-arrow"><i data-feather="chevron-right"></i></span>
          </a>
          <ul class="pc-submenu">
            <?php $__currentLoopData = $sidebar->subMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="pc-item"><a class="pc-link" href="<?php echo e(route($submenu->route_name)); ?>"><?php echo e($submenu->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </li>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  </div>
</nav><?php /**PATH /var/www/crm-app/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>