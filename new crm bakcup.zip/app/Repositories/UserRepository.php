<?php

namespace App\Repositories;
use App\Models\User;

class UserRepository
{

    public function get()
    {
        return User::with('role')->orderBy('id', 'desc')->get();
    }

    public function find($id)
    {
        return User::where('id', $id)->first();
    }

    public function create($data)
    {
        return User::create($data);
    }

    public function update($id, $data)
    {
        return User::where('id', $id)->update($data);
    }

    public function delete($id)
    {
        return User::where('id', $id)->delete();
    }

     public function getClientList()
    {
         $clients = User::whereHas('role', function ($query) {
            $query->where('id', 2);
        })->with('role')->get();
        return $clients;
    }

}

