<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Services\ProjectTypeService;
use App\Services\ClientService;
use Hash;

class ClientController extends Controller
{
    function __construct(ProjectTypeService $projectTypeService,ClientService $clientService,)
        {
            $this->projectTypeService=$projectTypeService;
            $this->clientService=$clientService;
        }

    public function index()
    {sdf fsd f  
        return view('superadmin.client.index');
    }

    public function clientList()
    {
        $clients = $this->clientService->get();
        echo 'asdsadsa';die;
        return DataTables::of($clients)
            ->addColumn('company_name', function ($client) {
                return $client->company_name;
            })
            ->addColumn('name', function ($client) {
                return $client->name;
            })
            ->addColumn('crm_scal', function ($client) {
                $list = '<ol>';
                $list .= '<li>' .'NA'. '</li>';
                $list .= '<li>' . 'NA'. '</li>';
                $list .= '</ol>';
                return $list;
            })
            ->addColumn('status', function ($client) {
                $statusClass = match ($client->status) {
                    'active' => 'text-success',
                    'inactive' => 'text-warning',
                    'delete' => 'text-danger'
                };
                return '<span class="' . $statusClass . '">' . ucfirst($client->status) . '</span>';
            })
            ->addColumn('action', function ($client) {
                return '<button class="btn btn-primary edit-btn" data-id="' . $client->id . '">
                            <i class="fas fa-pencil-alt"></i>
                        </button>
                        <button class="btn btn-danger delete-btn" data-id="' . $client->id . '">
                            <i class="fas fa-trash-alt"></i>
                        </button>';
            })
            ->rawColumns(['status', 'crm_scal', 'action'])
            ->make(true);
    }

    public function addClient(){
        $projct_type=$this->projectTypeService->get();
        return view('superadmin.client.create',compact('projct_type'));
    }

    public function clientStore(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'company_name'   => 'required|string|max:150',
            'client_name'    => 'required|string|max:150',
            'phone'          => 'required|digits:10',
            'email'          => 'required|email|unique:users,email',
            'projct_type_id' => 'required',
            'files'          => 'required|image|mimes:jpeg,png,jpg,webp|max:2048',
            'login_id'       => 'required|string|unique:users,login_id',
            'password'       => 'required|min:8',
            'confirm_password'=> 'required|min:8|same:password',
            'address'        => 'required|string|max:255',
            'status'         => 'required|in:Active,Inactive',
        ],
        [
            'confirm_password.same' => 'Passwords do not match.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors()
            ], 422);
        }
        $imageName = null;
        if ($request->hasFile('company_logo')) {
            $image = $request->file('company_logo');
            $imageName = uniqid() . '_' . $image->getClientOriginalName(); 
            $directory = \AppConfig::LOGO_UPLOAD_DIR_INTERNAL;
            if (!is_writable($directory)) {
                throw new \Exception("The directory {$directory} is not writable.");
            }
            $image->move($directory, $imageName);
        }
        
        $client = User::create([
            'role_id'           => 2,
            'company_name'      => $request->company_name,
            'name'              => $request->client_name,
            'phone'             => $request->phone,
            'login_id'          => $request->login_id,
            'company_logo'      => $imageName,
            'email'             => $request->email,
            'prject_type_id'    => $request->prject_type_id,
            'password'          => Hash::make($request->password),
            'remember_password' => $request->password,
            'status'            => $request->status,
        ]);
        return response()->json(['success' => true, 'message' => 'Client added successfully']);
    }

    public function userLimitEdit($id)
    {
        $UserLimit = User::findOrFail($id);
        return response()->json([
            'success' => true,
            'data' => [
                'id' => $UserLimit->id,
                'limit_number' => $UserLimit->limit_number,
                'status' => $UserLimit->status
            ]
        ]);
    }

    public function userLimitUpdate(Request $request)
    {
        $rules = [
            'userLimit_id' => 'required',
            'limit_number' => 'required',
            'status' => 'required',
        ];

        $errors = [];
        foreach ($rules as $field => $rule) {
            $validator = Validator::make($request->only($field), [$field => $rule]);
            if ($validator->fails()) {
                $errors[$field] = $validator->errors()->first($field);
                break;
            }
        }
        if (!empty($errors)) {
            return response()->json(['errors' => $errors], 422);
        }
        $UserLimit = User::where('id', $request->userLimit_id)->Update([
            'limit_number' => $request->limit_number,
            'status' => $request->status
        ]);
        return response()->json(['success' => true, 'message' => 'User Limit updated successfully']);
    }

    public function userLimitDelete(Request $request)
    {
        $UserLimit = User::where('id', $request->id)->Update([
            'status' => 'delete'
        ]);
        return response()->json(['success' => true, 'message' => 'User Limit delete successfully']);
    }
}

