<!-- Subscription Sidebar -->
<div id="AddSubscription" class="sdbr-sidebar-2x">
  <button class="sdbr-close-button" onclick="closeSubscriptionbar()">&times;</button>
  <h2>Add Subscription</h2>
  <hr>
  <form class="mt-2">
    <div class="row mb-2">
      <div class="col-6">
        <label class="text-lg-end mt-1 mb-2">Client Id:</label>
        <input type="text" class="form-control" value="ADWCRM0001" disabled>
      </div>
      <div class="col-6">
        <label class="text-lg-end mt-1 mb-2">Company Name:</label>
        <input type="text" class="form-control" value="Myspace Developers" disabled>
      </div>
    </div>
    <div class="row mb-2">
      <div class="col-6">
        <label class="text-lg-end mt-1 mb-2">Users:</label>
        <select class="form-control users-limit mb-2">
          <option selected disabled>Select require users</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
        </select>
      </div>
      <div class="col-6">
        <label class="text-lg-end mt-1 mb-2">Validity:</label>
        <select class="form-control users-limit mb-2">
          <option selected disabled>Select validity</option>
          <option value="1 Month">1 Month</option>
          <option value="3 Months">3 Months</option>
          <option value="6 Months">6 Months</option>
          <option value="12 Months">12 Months</option>
          <option value="2 Years">2 Years</option>
        </select>
      </div>
    </div>
    <div class="row mb-2">
      <div class="col-6">
        <label class="text-lg-end mt-1 mb-2">Subscription Amount (₹):</label>
        <input type="text" class="form-control" value="14999" disabled>
      </div>
      <div class="col-6">
        <label class="text-lg-end mt-1 mb-2">Apply Discount (₹):</label>
        <input type="text" class="form-control" placeholder="Add discount amount">
      </div>
    </div>
    <div class="row mb-3">
      <div class="col-6">
        <label class="text-lg-end mt-1 mb-2">Total GST (₹):</label>
        <input type="text" class="form-control" value="2699.82" disabled>
      </div>
      <div class="col-6">
        <label class="text-lg-end mt-1 mb-2">Total Payable Amount (₹):</label>
        <input type="text" class="form-control" placeholder="Add discount amount" value="12299.18" disabled>
      </div>
    </div>

    <div class="row">
      <div class="col-8">
        <button type="button" class="btn mt-2 btn-primary" style="width:100%;">Submit</button>
      </div>
      <div class="col-4">
        <button type="button" class="btn mt-2 btn-secondary" style="width:100%;">Reset</button>
      </div>
    </div>

  </form>
</div>

<?php /**PATH /home/pokq8ydq09to/app.abstractcrm.com/resources/views/superadmin/client/add-subscription-form.blade.php ENDPATH**/ ?>