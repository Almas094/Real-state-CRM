<div id="DownloadInvoice" class="sdbr-sidebar-3x">
    <button class="sdbr-close-button" onclick="closeDownloadInvoiceBar()">&times;</button>
    <h2>Download Invoice</h2>
    <hr>
    <div class="crm-invoice-box">
      <div class="crm-header">
          <div class="crm-header-left">
              <h1>Invoice</h1>
              <p>Invoice #: 12345</p>
              <p>Date: 2024-12-18</p>
              <p>Due Date: 2025-01-18</p>
          </div>
          <div class="crm-header-right">
              <h2>Company Name</h2>
              <p>123 Business Street</p>
              <p>City, State, 12345</p>
              <p>Email: info@company.com</p>
          </div>
      </div>
      <div class="crm-main">
          <section class="crm-client-details">
              <h3>Bill To:</h3>
              <p>Client Name</p>
              <p>456 Client Avenue</p>
              <p>City, State, 67890</p>
              <p>Email: client@example.com</p>
          </section>
          <table class="crm-invoice-table">
              <thead>
                  <tr>
                      <th>#</th>
                      <th>Description</th>
                      <th>Quantity</th>
                      <th>Unit Price</th>
                      <th>Total</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>1</td>
                      <td>Web Development Services</td>
                      <td>1</td>
                      <td>$1,000.00</td>
                      <td>$1,000.00</td>
                  </tr>
                  <tr>
                      <td>2</td>
                      <td>Hosting Services</td>
                      <td>12</td>
                      <td>$50.00</td>
                      <td>$600.00</td>
                  </tr>
              </tbody>
          </table>
      </div>
      <div class="crm-footer">
          <div class="crm-footer-left">
              <h3>Payment Information</h3>
              <p>Bank: XYZ Bank</p>
              <p>Account #: 123456789</p>
              <p>IFSC: XYZB12345</p>
          </div>
          <div class="crm-footer-right">
              <h3>Total Amount</h3>
              <p>$1,600.00</p>
          </div>
      </div>
      <button class="crm-print-btn" onclick="window.print()">Print Invoice</button>
    </div>
</div>

<?php /**PATH D:\xampp\htdocs\adw-new-crm\resources\views/superadmin/billing/download-invoice.blade.php ENDPATH**/ ?>