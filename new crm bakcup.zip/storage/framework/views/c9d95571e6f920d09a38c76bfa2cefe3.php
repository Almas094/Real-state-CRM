<div class="auth-footer">
  <p class="m-0 w-100 text-center"><strong>By signing up, you confirm to have read ABSTRACT CRM <a href="#" class="link-1">Privacy Policy</a> and agree to the
  <a href="#" class="link-1">Terms of Service</a>.</strong>
  </p>
</div><?php /**PATH D:\xampp\htdocs\adw-new-crm\resources\views/auth/footer.blade.php ENDPATH**/ ?>