

<?php $__env->startSection('title', 'Abstract CRM'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/dataTables.bootstrap5.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/responsive.bootstrap5.min.css')); ?>">
<?php $__env->startSection('content'); ?>
<section class="pc-container">
  <div class="pc-content">

    <div class="page-header" style="padding-top:0px; margin-top:-5px;">
      <div class="page-block">
        <div class="row align-items-center">
          <div class="col-md-12">
            <div class="page-header-title">
              <h2 class="mb-3">Configuration List</h2>
            </div>
          </div>
          <div class="col-md-12">
            <ul class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item"><a>Master</a></li>
              <li class="breadcrumb-item" aria-current="page">Configuration List</li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
        <div class="col-sm-12">
            <div class="card">
              <div class="card-header table-header">
                <div class="row">
                    <div class="col-8">
                        <h5 class="mt-2">Configuration List</h5>
                    </div>
                    <div class="col-4 text-right">
                        <button type="button" class="btn btn-primary me-3 d-inline-flex" id="openSidebarBtn"><i class="ti ti-circle-plus me-2"></i>Add Configuration</button>
                    </div>
                </div>
              </div>
              <div class="card-body">
                <div class="table-responsive dt-responsive">
                  <table id="dom-jqry" class="table table-striped table-bordered nowrap">
                    <thead>
                      <tr>
                        <th class="ms-3">Sr. No.</th>
                        <th >Name</th>
                        <th class="text-center">Created At</th>
                        <th class="text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td class="ms-3">01</td>
                        <td>1 BHK</td>
                        <td class="text-center">27/11/2024</td>
                        <td class="text-center form-switch">
                            <input type="checkbox" class="form-check-input input-success mt-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Active / Inactive" checked>
                            <button type="button" class="btn btn-icon btn-light-danger wh-30"  data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"><i class="ti ti-backspace"></i></button>
                        </td>
                      </tr>
                      <tr>
                        <td class="ms-3">02</td>
                        <td>2 BHK</td>
                        <td class="text-center">29/11/2024</td>
                        <td class="text-center form-switch">
                            <input type="checkbox" class="form-check-input input-success mt-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Active / Inactive" checked>
                            <button type="button" class="btn btn-icon btn-light-danger wh-30"  data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"><i class="ti ti-backspace"></i></button>
                        </td>
                      </tr>
                      <tr>
                        <td class="ms-3">03</td>
                        <td>3 BHK</td>
                        <td class="text-center">27/11/2024</td>
                        <td class="text-center form-switch">
                            <input type="checkbox" class="form-check-input input-success mt-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Active / Inactive" checked>
                            <button type="button" class="btn btn-icon btn-light-danger wh-30"  data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"><i class="ti ti-backspace"></i></button>
                        </td>
                      </tr>
                      <tr>
                        <td class="ms-3">04</td>
                        <td>1 RK</td>
                        <td class="text-center">27/11/2024</td>
                        <td class="text-center form-switch">
                            <input type="checkbox" class="form-check-input input-success mt-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Active / Inactive" checked>
                            <button type="button" class="btn btn-icon btn-light-danger wh-30"  data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"><i class="ti ti-backspace"></i></button>
                        </td>
                      </tr>
                      <tr>
                        <td class="ms-3">05</td>
                        <td>Studio</td>
                        <td class="text-center">27/11/2024</td>
                        <td class="text-center form-switch">
                            <input type="checkbox" class="form-check-input input-success mt-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Active / Inactive" checked>
                            <button type="button" class="btn btn-icon btn-light-danger wh-30"  data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"><i class="ti ti-backspace"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
    </div>


    <!-- Form Sidebar -->

    <div class="crm-sidebar" id="crmSidebar">
        <button class="crm-close-btn" id="closeSidebarBtn">&times;</button>
        <h2>Add Configuration</h2>

        <form id="AddConfigurationForm" class="mt-3">
            <div class="form-group">
                <label class="form-label" for="AddConfiguration">Configuration</label>
                <input type="text" class="form-control" id="AddConfiguration" placeholder="Please enter value">
                <div class="error-message" id="configError">This field is required.</div>
            </div>

            <div class="form-group">
                <label class="form-label" for="StatusConfiguration">Status</label>
                <select class="form-select" id="StatusConfiguration">
                    <option value="" disabled selected>Please select status</option>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                </select>
                <div class="error-message" id="statusError">Please select a status.</div>
            </div>

            <button type="submit" class="btn btn-primary mt-2">Submit</button>
        </form>
    </div>


    <div class="crm-overlay" id="crmOverlay"></div>

    <!-- Add Limit Modal -->
    <?php echo $__env->make('superadmin.master.add-user-limit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Add Limit Modal -->

    <!-- Edit Limit Modal -->
    <?php echo $__env->make('superadmin.master.edit-user-limit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Edit Limit Modal -->

    <?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/plugins/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/responsive.bootstrap5.min.js')); ?>"></script>
     <!-- Required Js -->
    <script src="<?php echo e(asset('assets/js/plugins/popper.min')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/simplebar.min')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/bootstrap.min')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/fonts/custom-font')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/config')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pcoded')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/feather.min')); ?>"></script>

    <script>
      // [ DOM/jquery ]
      var total, pageTotal;
      var table = $('#dom-jqry').DataTable();
      // [ column Rendering ]
      $('#colum-render').DataTable({
        columnDefs: [
          {
            render: function (data, type, row) {
              return data + ' (' + row[3] + ')';
            },
            targets: 0
          },
          {
            visible: false,
            targets: [3]
          }
        ]
      });
      // [ Multiple Table Control Elements ]
      $('#multi-table').DataTable({
        dom: '<"top"iflp<"clear">>rt<"bottom"iflp<"clear">>'
      });
      // [ Complex Headers With Column Visibility ]
      $('#complex-header').DataTable({
        columnDefs: [
          {
            visible: false,
            targets: -1
          }
        ]
      });
      // [ Language file ]
      $('#lang-file').DataTable({
        language: {
          url: '//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/German.json'
        }
      });
      // [ Setting Defaults ]
      $('#setting-default').DataTable();
      // [ Row Grouping ]
      var table1 = $('#row-grouping').DataTable({
        columnDefs: [
          {
            visible: false,
            targets: 2
          }
        ],
        order: [[2, 'asc']],
        displayLength: 25,
        drawCallback: function (settings) {
          var api = this.api();
          var rows = api
            .rows({
              page: 'current'
            })
            .nodes();
          var last = null;

          api
            .column(2, {
              page: 'current'
            })
            .data()
            .each(function (group, i) {
              if (last !== group) {
                $(rows)
                  .eq(i)
                  .before('<tr class="group"><td colspan="5">' + group + '</td></tr>');

                last = group;
              }
            });
        }
      });
      // [ Order by the grouping ]
      $('#row-grouping tbody').on('click', 'tr.group', function () {
        var currentOrder = table.order()[0];
        if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
          table.order([2, 'desc']).draw();
        } else {
          table.order([2, 'asc']).draw();
        }
      });
      // [ Footer callback ]
      $('#footer-callback').DataTable({
        footerCallback: function (row, data, start, end, display) {
          var api = this.api(),
            data;

          // Remove the formatting to get integer data for summation
          var intVal = function (i) {
            return typeof i === 'string' ? i.replace(/[\$,]/g, '') * 1 : typeof i === 'number' ? i : 0;
          };

          // Total over all pages
          total = api
            .column(4)
            .data()
            .reduce(function (a, b) {
              return intVal(a) + intVal(b);
            }, 0);

          // Total over this page
          pageTotal = api
            .column(4, {
              page: 'current'
            })
            .data()
            .reduce(function (a, b) {
              return intVal(a) + intVal(b);
            }, 0);

          // Update footer
          $(api.column(4).footer()).html('$' + pageTotal + ' ( $' + total + ' total)');
        }
      });
      // [ Custom Toolbar Elements ]
      $('#c-tool-ele').DataTable({
        dom: '<"toolbar">frtip'
      });
      // [ Custom Toolbar Elements ]
      $('div.toolbar').html('<b>Custom tool bar! Text/images etc.</b>');
      // [ custom callback ]
      $('#row-callback').DataTable({
        createdRow: function (row, data, index) {
          if (data[5].replace(/[\$,]/g, '') * 1 > 150000) {
            $('td', row).eq(5).addClass('highlight');
          }
        }
      });
    </script>

    <script>
      // Add Configuration Form Validation

      document.getElementById('AddConfigurationForm').addEventListener('submit', function (event) {
          event.preventDefault(); // Prevent form submission

          // Get form elements
          const configurationInput = document.getElementById('AddConfiguration');
          const configError = document.getElementById('configError');

          const statusSelect = document.getElementById('StatusConfiguration');
          const statusError = document.getElementById('statusError');

          let isValid = true;

          // Reset error states
          configurationInput.classList.remove('error');
          configError.style.display = 'none';

          statusSelect.classList.remove('error');
          statusError.style.display = 'none';

          // Validate Configuration Input
          if (configurationInput.value.trim() === '') {
              isValid = false;
              configurationInput.classList.add('error');
              configError.style.display = 'block';
          }

          // Validate Status Select
          if (!statusSelect.value) {
              isValid = false;
              statusSelect.classList.add('error');
              statusError.style.display = 'block';
          }

          // If valid, submit the form (or do other actions)
          if (isValid) {

              window.location.href = "https://app.abstractcrm.com/client/master/configuration-list"; 

          }
      });

    </script>


 <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/crm-app/resources/views/client/masters/configration-masters.blade.php ENDPATH**/ ?>