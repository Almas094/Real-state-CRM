<footer class="pc-footer" >
  <div class="footer-wrapper container-fluid">
    <div class="row">
      <div class="col my-1">
        <p class="m-0">Abstract CRM &#9829; Powered by <a href="https://abstractdigitalworld.com/" target="_blank">Abstract Digital World Pvt Ltd.</a></p>
      </div>
      <div class="col-auto my-1">
        <ul class="list-inline footer-link mb-0">
          <li class="list-inline-item"><a href="https://abstractdigitalworld.com/">Home</a></li>
          <li class="list-inline-item"><a href="https://abstractdigitalworld.com/" target="_blank">Documentation</a></li>
          <li class="list-inline-item"><a href="https://abstractdigitalworld.com/" target="_blank">Support</a></li>
        </ul>
      </div>
    </div>
  </div>
</footer><?php /**PATH /var/www/crm-app/resources/views/partials/client-footer.blade.php ENDPATH**/ ?>