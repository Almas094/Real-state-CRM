<footer class="pc-footer super-footer" >
  <div class="footer-wrapper container">
    <div class="row">
      <div class="col-12 my-1 text-right">
        <p class="m-0">Abstract CRM &#9829; Powered by <a href="https://abstractdigitalworld.com/" target="_blank">Abstract Digital World Pvt Ltd.</a></p>
      </div>
    </div>
  </div>
</footer>

<!-- Required Js -->
<script src="<?php echo e(asset('assets/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins/dataTables.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins/responsive.bootstrap5.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/plugins/popper.min')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins/simplebar.min')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins/bootstrap.min')); ?>"></script>
<script src="<?php echo e(asset('assets/js/fonts/custom-font')); ?>"></script>
<script src="<?php echo e(asset('assets/js/config')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pcoded')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins/feather.min')); ?>"></script>
<?php /**PATH /home/pokq8ydq09to/app.abstractcrm.com/resources/views/partials/admin-footer.blade.php ENDPATH**/ ?>