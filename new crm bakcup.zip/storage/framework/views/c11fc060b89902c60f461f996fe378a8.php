<!-- Filter Sidebar -->
<div id="InvoiceStatusBar" class="sdbr-sidebar">
  <button class="sdbr-close-button" onclick="closeInvoiceStatusBar()">&times;</button>
  <h2>Update Billing Status</h2>
  <hr>
  <form class="mt-2" id="UpdateBillingStatus">
    <label class="text-lg-end mt-1 mb-2">Invoice Id:</label>
    <input type="text" class="form-control  mb-2" value="ADW0006" disabled>

    <label class="text-lg-end mt-1 mb-2">Company Name:</label>
    <input type="text" class="form-control  mb-2" value="Myspace Developers" disabled>

    <label class="text-lg-end mt-2 mb-2" for="UpdateStatus">Invoice Status:</label>
    <select class="form-control billing-status-select mb-2" id="UpdateStatus" required>
      <option selected disabled value="">Change Payment Status</option>
      <option value="Paid">Paid</option>
      <option value="Unpaid">Unpaid</option>
      <option value="Cancelled">Cancelled</option>
    </select>
    <div class="error-message" id="UpdateStatusError">Status is required.</div>

    <button type="button" class="btn mt-3 btn-primary" id="UpdateStatusBtn" style="width:100%;">Update</button>
  </form>
</div>
<script>
  document.getElementById('UpdateStatusBtn').addEventListener('click', function () {
    let isValid = true; // Track form validity

    function validateField(id, errorId, condition, errorMessage) {
      const field = document.getElementById(id);
      const errorField = document.getElementById(errorId);

      if (condition) {
        errorField.style.display = 'none';
        field.classList.remove('is-invalid');
      } else {
        errorField.textContent = errorMessage;
        errorField.style.display = 'block';
        field.classList.add('is-invalid');
        isValid = false;
      }
    }

    // Validate fields
    validateField(
      'UpdateStatus',
      'UpdateStatusError',
      document.getElementById('UpdateStatus').value.trim() !== "",
      'Status is required.'
    );

    if (isValid) {
      // Add success message below the form
      const form = document.getElementById('UpdateBillingStatus');
      let successMessage = document.getElementById('formSuccessMessage');

      if (!successMessage) {
        successMessage = document.createElement('div');
        successMessage.id = 'formSuccessMessage';
        successMessage.className = 'alert alert-success mt-3';
        form.appendChild(successMessage);
      }

      successMessage.textContent = 'Nice, Payment status successfully updated.';
      successMessage.style.display = 'block';

      // Reset the form after submission
      document.getElementById('UpdateStatus').value = ""; // Reset the dropdown

      // Hide the success message after 3 seconds
      setTimeout(() => {
        successMessage.style.display = 'none';
      }, 1500);
    }
  });
</script>
<?php /**PATH /var/www/crm-app/resources/views/superadmin/billing/invoice-status.blade.php ENDPATH**/ ?>