

<?php $__env->startSection('title', 'Abstract CRM'); ?>


<?php $__env->startSection('content'); ?>
<section class="pc-container">
  <div class="pc-content">

    <!-- Section Header -->
    <div class="page-header" style="padding-top:0px;">
      <div class="page-block">
        <div class="row align-items-center">
          <div class="col-md-12">
            <div class="page-header-title">
              <h4 class="mb-2">All Clients</h4>
            </div>
          </div>
          <div class="col-md-12">
            <ul class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">SuperCRM</a></li>
              <li class="breadcrumb-item"><a>Clients</a></li>
              <li class="breadcrumb-item" aria-current="page">All Clients</li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <div class="row card-row-1">
        <div class="col-sm-12">
            <div class="card table-card">
              <div class="card-header table-header">
                <div class="row">
                    <div class="col-10">
                      <a href="/admin/client/add-client"><button type="button" class="btn btn-primary me-3 d-inline-flex btn-i-wh15px"><i data-feather="user-plus" class="me-1 mt-1 wh15px"></i>Add Client</button></a> 
                    </div>
                    <div class="col-2 text-right">
                      <button type="button" class="btn btn-primary me-3 d-inline-flex btn-i-wh15px" onclick="openFilterbar()"><i data-feather="filter" class="me-1 mt-1 wh15px"></i>Filter</button> 
                    </div>
                </div>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-hover client-table" id="clientTable">
                    <thead>
                      <tr>
                        <th>Sr.No.</th>
                        <th>Client Details</th>
                        <th>Contact</th>
                        <th>Subscription</th>
                        <th>Duration</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody class="cmb-5">
                      <tr>
                        <td>01</td>
                        <td>
                            <h6 class="mb-2">Myspace Developers</h6>
                            <p class="f-14 mb-0">POC: Akanksha Loke</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">+91 8108910100</p>
                          <p class="f-14 mb-0">info@myspace.homes</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">Users: 1</p>
                          <p class="f-14 mb-0">Validity: 7 days</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">From: 01-01-2025</p>
                          <p class="f-14 mb-0">To: 07-01-2025</p>
                        </td>
                        <td class="text-center">
                          <span class="badge bg-light-warning mb-2">7 Days Trial</span><br>
                          <span class="badge bg-light-success">Active</span>                          
                        </td>
                        <td class="text-center">
                          <div class="btn-group mr-2 mb-2">
                            <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                            <ul class="dropdown-menu dropdown-action-1">
                              <li><a class="dropdown-item f-13" href="#" onclick="openViewClientDetails()" ><i class="ti ti-eye"></i>View Details</a></li>
                              <li><a class="dropdown-item f-13" href="#"><i class="ti ti-edit"></i>Change Status</a></li>
                              <li><a class="dropdown-item f-13" href="#" onclick="openSubscriptionbar()" ><i class="ti ti-brand-pocket"></i>Manage Subscription</a></li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>02</td>
                        <td>
                            <h6 class="mb-2">Myspace Developers</h6>
                            <p class="f-14 mb-0">POC: Akanksha Loke</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">+91 8108910110</p>
                          <p class="f-14 mb-0">info@myspace.homes</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">Users: 1</p>
                          <p class="f-14 mb-0">Validity: 7 days</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">From: 25-12-2024</p>
                          <p class="f-14 mb-0">To: 31-12-2024</p>
                        </td>
                        <td class="text-center">
                          <span class="badge bg-light-warning mb-2">7 Days Trial</span><br>
                          <span class="badge bg-light-danger">Inactive</span>
                        </td>
                        <td class="text-center">
                          <div class="btn-group mr-2 mb-2">
                            <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                            <ul class="dropdown-menu dropdown-action-1">
                              <li><a class="dropdown-item f-13" href="#"  onclick="openViewClientDetails()"><i class="ti ti-eye"></i>View Details</a></li>
                              <li><a class="dropdown-item f-13" href="#"><i class="ti ti-edit"></i>Change Status</a></li>
                              <li><a class="dropdown-item f-13" href="#"onclick="openSubscriptionbar()" ><i class="ti ti-brand-pocket"></i>Manage Subscription</a></li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>03</td>
                        <td>
                            <h6 class="mb-2">Myspace Developers</h6>
                            <p class="f-14 mb-0">POC: Akanksha Loke</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">+91 8108910100</p>
                          <p class="f-14 mb-0">info@myspace.homes</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">Users: 10</p>
                          <p class="f-14 mb-0">Validity: 12 months</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">From: 01/01/2025</p>
                          <p class="f-14 mb-0">To: 31/12/2025</p>
                        </td>
                        <td class="text-center">
                          <span class="badge bg-light-danger mb-2">Unpaid</span><br>
                          <span class="badge bg-light-success">Active</span>
                        </td>
                        <td class="text-center">
                          <div class="btn-group mr-2 mb-2">
                            <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                            <ul class="dropdown-menu dropdown-action-1">
                              <li><a class="dropdown-item f-13" href="#"  onclick="openViewClientDetails()"><i class="ti ti-eye"></i>View Details</a></li>
                              <li><a class="dropdown-item f-13" href="#"><i class="ti ti-edit"></i>Change Status</a></li>
                              <li><a class="dropdown-item f-13" href="#"onclick="openSubscriptionbar()" ><i class="ti ti-brand-pocket"></i>Manage Subscription</a></li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>04</td>
                        <td>
                            <h6 class="mb-2">Myspace Developers</h6>
                            <p class="f-14 mb-0">POC: Akanksha Loke</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">+91 8108910100</p>
                          <p class="f-14 mb-0">info@myspace.homes</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">Users: 10</p>
                          <p class="f-14 mb-0">Validity: 12 months</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">From: 01/01/2025</p>
                          <p class="f-14 mb-0">To: 31/12/2025</p>
                        </td>
                        <td class="text-center">
                          <span class="badge bg-light-danger mb-2">Unpaid</span><br>
                          <span class="badge bg-light-danger">Inactive</span>
                        </td>
                        <td class="text-center">
                          <div class="btn-group mr-2 mb-2">
                            <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                            <ul class="dropdown-menu dropdown-action-1">
                              <li><a class="dropdown-item f-13" href="#"  onclick="openViewClientDetails()"><i class="ti ti-eye"></i>View Details</a></li>
                              <li><a class="dropdown-item f-13" href="#"><i class="ti ti-edit"></i>Change Status</a></li>
                              <li><a class="dropdown-item f-13" href="#"onclick="openSubscriptionbar()" ><i class="ti ti-brand-pocket"></i>Manage Subscription</a></li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>05</td>
                        <td>
                            <h6 class="mb-2">Myspace Developers</h6>
                            <p class="f-14 mb-0">POC: Akanksha Loke</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">+91 8108910100</p>
                          <p class="f-14 mb-0">info@myspace.homes</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">Users: 10</p>
                          <p class="f-14 mb-0">Validity: 12 months</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">From: 01/01/2025</p>
                          <p class="f-14 mb-0">To: 31/12/2025</p>
                        </td>
                        <td class="text-center">
                          <span class="badge bg-light-success mb-2">Paid</span><br>
                          <span class="badge bg-light-success">Active</span>
                        </td>
                        <td class="text-center">
                          <div class="btn-group mr-2 mb-2">
                            <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                            <ul class="dropdown-menu dropdown-action-1">
                              <li><a class="dropdown-item f-13" href="#"  onclick="openViewClientDetails()"><i class="ti ti-eye"></i>View Details</a></li>
                              <li><a class="dropdown-item f-13" href="#"><i class="ti ti-edit"></i>Change Status</a></li>
                              <li><a class="dropdown-item f-13" href="#"onclick="openSubscriptionbar()" ><i class="ti ti-brand-pocket"></i>Manage Subscription</a></li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>06</td>
                        <td>
                            <h6 class="mb-2">Myspace Developers</h6>
                            <p class="f-14 mb-0">POC: Akanksha Loke</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">+91 8108910100</p>
                          <p class="f-14 mb-0">info@myspace.homes</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">Users: 10</p>
                          <p class="f-14 mb-0">Validity: 12 months</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">From: 01/01/2025</p>
                          <p class="f-14 mb-0">To: 31/12/2025</p>
                        </td>
                        <td class="text-center">
                          <span class="badge bg-light-danger mb-2">Unpaid</span><br>
                          <span class="badge bg-light-success">Active</span>
                        </td>
                        <td class="text-center">
                          <div class="btn-group mr-2 mb-2">
                            <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                            <ul class="dropdown-menu dropdown-action-1">
                              <li><a class="dropdown-item f-13" href="#"  onclick="openViewClientDetails()"><i class="ti ti-eye"></i>View Details</a></li>
                              <li><a class="dropdown-item f-13" href="#"><i class="ti ti-edit"></i>Change Status</a></li>
                              <li><a class="dropdown-item f-13" href="#"onclick="openSubscriptionbar()" ><i class="ti ti-brand-pocket"></i>Manage Subscription</a></li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>07</td>
                        <td>
                            <h6 class="mb-2">Myspace Developers</h6>
                            <p class="f-14 mb-0">POC: Akanksha Loke</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">+91 8108910100</p>
                          <p class="f-14 mb-0">info@myspace.homes</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">Users: 10</p>
                          <p class="f-14 mb-0">Validity: 12 months</p>
                        </td>
                        <td>
                          <p class="f-14 mb-2">From: 01/01/2025</p>
                          <p class="f-14 mb-0">To: 31/12/2025</p>
                        </td>
                        <td class="text-center">
                          <span class="badge bg-light-success mb-2">Paid</span><br>
                          <span class="badge bg-light-success">Active</span>
                        </td>
                        <td class="text-center">
                          <div class="btn-group mr-2 mb-2">
                            <i class="ti ti-menu-2 f-30 cursor-p" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false"></i>
                            <ul class="dropdown-menu dropdown-action-1">
                              <li><a class="dropdown-item f-13" href="#"  onclick="openViewClientDetails()"><i class="ti ti-eye"></i>View Details</a></li>
                              <li><a class="dropdown-item f-13" href="#"><i class="ti ti-edit"></i>Change Status</a></li>
                              <li><a class="dropdown-item f-13" href="#"onclick="openSubscriptionbar()" ><i class="ti ti-brand-pocket"></i>Manage Subscription</a></li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
    </div>

    <!-- FilterBar -->
    <?php echo $__env->make('superadmin.client.client-table-filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- SubscriptionBar -->
    <?php echo $__env->make('superadmin.client.add-subscription-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ViewDetailsBar -->
    <?php echo $__env->make('superadmin.client.view-client-details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div id="sdbr-overlay" class="sdbr-overlay" onclick="closeAllSidebars()"></div>

  <?php $__env->startPush('scripts'); ?>


<!-- [Page Specific JS] start -->
<script src="<?php echo e(asset('assets/js/plugins/simple-datatables.js')); ?>"></script>
<script>
  const dataTable = new simpleDatatables.DataTable('#clientTable', {
    sortable: false,
    perPage: 5
  });
</script>

<script src="<?php echo e(asset('assets/js/plugins/datepicker-full.min.js')); ?>"></script>
<script>
  // date range picker
  (function () {
    const datepicker_range = new DateRangePicker(document.querySelector('#expiration-datepicker'), {
      buttonClass: 'btn'
    });
  })();
</script>

<!-- Sidebars -->
<script>
  const overlay = document.getElementById('sdbr-overlay');

  function openFilterbar() {
    const sidebar = document.getElementById('FilterBar');
    sidebar.classList.add('open');
    overlay.classList.add('show');
  }

  function closeFilterbar() {
    const sidebar = document.getElementById('FilterBar');
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
  }

  function openSubscriptionbar() {
    const sidebar = document.getElementById('AddSubscription');
    sidebar.classList.add('open');
    overlay.classList.add('show');
  }

  function closeSubscriptionbar() {
    const sidebar = document.getElementById('AddSubscription');
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
  }

  function openViewClientDetails() {
    const sidebar = document.getElementById('ViewClientDetails');
    sidebar.classList.add('open');
    overlay.classList.add('show');
  }

  function closeViewClientDetails() {
    const sidebar = document.getElementById('ViewClientDetails');
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
  }

  function closeAllSidebars() {
    closeFilterbar();
    closeSubscriptionbar();
    closeViewClientDetails();
  }
</script>

<!-- MultiSelect -->
<script src="<?php echo e(asset('assets/js/plugins/choices.min.js')); ?>"></script>
<script>
  document.addEventListener('DOMContentLoaded', function () {

    var multipleCancelButton = new Choices('#Filter-Billing-Status', {
      removeItemButton: true,
      placeholderValue: 'Select billing status'
    });

    var multipleCancelButton = new Choices('#Filter-Users-Limit', {
      removeItemButton: true,
      placeholderValue: 'Select user limits'
    });

    var multipleCancelButton = new Choices('#Filter-Validity', {
      removeItemButton: true,
      placeholderValue: 'Select plan validity'
    });

    var multipleCancelButton = new Choices('#Filter-CRM-Status', {
      removeItemButton: true,
      placeholderValue: 'Select CRM status '
    });

  });
</script>


 <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.supercrm-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\adw-new-crm\resources\views/superadmin/client/client-list.blade.php ENDPATH**/ ?>