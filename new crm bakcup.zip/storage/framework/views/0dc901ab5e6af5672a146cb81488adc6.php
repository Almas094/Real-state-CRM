<div id="FilterBar" class="sdbr-sidebar">
  <button class="sdbr-close-button" onclick="closeFilterbar()">&times;</button>
  <h2>Filter Clients</h2>
  
  <form class="mt-2">
    <label class="text-lg-end mt-1 mb-2">Plan Expiration:</label>
    <div class="input-daterange input-group mb-2" id="expiration-datepicker">
      <input type="text" class="form-control text-left" placeholder="Start date" name="range-start">
      <span class="input-group-text">to</span>
      <input type="text" class="form-control text-end date-range-end" placeholder="End date" name="range-end">
    </div>

    <label class="text-lg-end mt-2 mb-2">Billing Status:</label>
    <select class="form-control billing-status-select mb-2" name="Filter-Billing-Status" id="Filter-Billing-Status" multiple>
      <option value="Paid">Paid</option>
      <option value="Unpaid">Unpaid</option>
      <option value="Cancelled">Cancelled</option>
    </select>

    <label class="text-lg-end mt-2 mb-2">Users limit:</label>
    <select class="form-control users-limit mb-2" name="Filter-Users-Limit" id="Filter-Users-Limit" multiple>
      <option value="3">3</option>
      <option value="4">4</option>
      <option value="5">5</option>
      <option value="6">6</option>
      <option value="7">7</option>
    </select>

    <label class="text-lg-end mt-2 mb-2">Validity:</label>
    <select class="form-control users-limit mb-2" name="Filter-Validity" id="Filter-Validity" multiple>
      <option value="7 Days - Trial">7 Days Trial</option>
      <option value="1 Month">1 Month</option>
      <option value="3 Months">3 Months</option>
      <option value="6 Months">6 Months</option>
      <option value="12 Months">12 Months</option>
      <option value="2 Years">2 Years</option>
    </select>

    <label class="text-lg-end mt-2 mb-2">CRM Status:</label>
    <select class="form-control users-limit mb-2" name="Filter-CRM-Status" id="Filter-CRM-Status" multiple>
      <option value="Active">Active</option>
      <option value="Inactive">Inactive</option>
    </select>

    <button type="button" class="btn mt-2 btn-primary" style="width:100%;">Search</button>
  </form>

</div>



<?php /**PATH /var/www/crm-app/resources/views/superadmin/client/client-table-filter.blade.php ENDPATH**/ ?>